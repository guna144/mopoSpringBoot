/**
 * 
 */
package com.mopo.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.mopo.demo.exception.MopokensException;
import com.mopo.demo.model.Breeder;
import com.mopo.demo.model.Mopoken;
import com.mopo.demo.model.MopokenGroup;
import com.mopo.demo.model.MopokensType;

/**
 * @author Guna Palani
 *
 */
@Service
public class MopokenService {

	public List<Mopoken> generateMopokens(String input) throws MopokensException {
        List<Mopoken> mopokens = new ArrayList<>();
        try {
            String[] mopoInput = input.split(";");
            for (String mopoken : mopoInput) {
                String[] mopokenParams = mopoken.split("#");
                MopokensType mopokensType = MopokensType.valueOf(mopokenParams[0].toUpperCase());
                Integer level = new Integer(mopokenParams[1]);
                Mopoken mopokenTypeLevel = new Mopoken(mopokensType, level);
                mopokens.add(mopokenTypeLevel);
            }
            return mopokens;
        } catch (Exception e) {
        	System.out.println(e.getMessage());
            throw new MopokensException("<font color='red'>Please enter valid input </font> [eg] : <b>Fire#10;</b> and <b>Water#10;</b>");
        }
    }

    public Breeder createBreeder(String input) throws MopokensException {

        List<Mopoken> mopokens = generateMopokens(input);
        if (mopokens.isEmpty()) {
            return null;
        }
        Breeder breeder = new Breeder();
        for (Mopoken mopoken : mopokens)
            breeder.getMopoGroup().add(mopoken);
        return breeder;
    }

    public String startFight(Breeder breeder, Breeder opponentBreeder) {

    	MopokenGroup opponetMopoGroup = opponentBreeder.getMopoGroup();
        return breeder.arrangeMopokens(opponetMopoGroup);
    }
}
