/**
 * 
 */
package com.mopo.demo.helper;

import java.util.ArrayList;
import java.util.List;

import com.mopo.demo.comparator.MopokenCompartor;
import com.mopo.demo.model.Mopoken;

/**
 * @author Guna Palani
 *
 */
public class MopokenResult {
	
	MopokenCompartor compartor = new MopokenCompartor();
    private Mopoken opponentMopoken;
    private List<Mopoken> resultList;
    public Mopoken getOpponentMopoken() {
		return opponentMopoken;
	}

	public void setOpponentMopoken(Mopoken opponentMopoken) {
		this.opponentMopoken = opponentMopoken;
	}

	public List<Mopoken> getResultList() {
		return resultList;
	}

	public void setResultList(List<Mopoken> resultList) {
		this.resultList = resultList;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	private Integer score = 0;

    public MopokenResult(Mopoken opponentMopoken) {
        this.opponentMopoken = opponentMopoken;
        this.resultList = new ArrayList<>();
    }

    public boolean add(Mopoken mopoken) {

        if ((mopoken == null || (compartor.compare(mopoken, opponentMopoken)) < 0 || !mopoken.isAvailable())) {
            return false;
        }
        score = compartor.compare(mopoken, opponentMopoken);
        return resultList.add(mopoken);
    }
}
