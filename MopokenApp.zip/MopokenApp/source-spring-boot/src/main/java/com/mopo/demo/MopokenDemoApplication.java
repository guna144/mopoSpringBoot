package com.mopo.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MopokenDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MopokenDemoApplication.class, args);
	}
}
