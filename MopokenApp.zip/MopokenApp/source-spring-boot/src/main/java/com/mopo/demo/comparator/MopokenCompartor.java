/**
 * 
 */
package com.mopo.demo.comparator;

import java.util.Comparator;

import com.mopo.demo.model.Mopoken;
import com.mopo.demo.model.MopokensType;

/**
 * @author Guna Palani
 *
 */
public class MopokenCompartor implements Comparator<Mopoken> {
	
	@Override
    public int compare(Mopoken o1, Mopoken o2) {

        if (o2.getLevel() >= (2 * o1.getLevel())) {
            return -1;
        }

        if (o1.getLevel() >= (2 * o2.getLevel())) {
            return 1;
        } else if (o1.equals(o2)) {
            return 0;
        } else if (o1.getType() == MopokensType.FIRE && (o2.getType() == MopokensType.GRASS || o2.getType() == MopokensType.GHOST)) {
            return 1;
        } else if (o1.getType() == MopokensType.WATER && o2.getType() == MopokensType.FIRE) {
            return 1;
        } else if (o1.getType() == MopokensType.GRASS && (o2.getType() == MopokensType.ELECTRIC || o2.getType() == MopokensType.FIGHTING)) {
            return 1;
        } else if (o1.getType() == MopokensType.ELECTRIC && o2.getType() == MopokensType.WATER) {
            return 1;
        } else if (o1.getType() == MopokensType.PSYCHIC && o2.getType() == MopokensType.GHOST) {
            return 1;
        } else if (o1.getType() == MopokensType.GHOST && (o2.getType() == MopokensType.FIGHTING
                || o2.getType() == MopokensType.ELECTRIC)) {
            return 1;
        } else if (o1.getType() == MopokensType.FIGHTING && o2.getType() == MopokensType.ELECTRIC) {
            return 1;
        } else if (o1.getType() == o2.getType() && o1.getLevel() > o2.getLevel()) {
            return 1;
        }

        return -1;
    }
}
