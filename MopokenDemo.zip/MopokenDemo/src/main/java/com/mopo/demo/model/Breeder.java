/**
 * 
 */
package com.mopo.demo.model;

import com.mopo.demo.helper.MopokenGroupSorter;

/**
 * @author Guna Palani
 *
 */
public class Breeder {
	
	private MopokenGroup mopoGroup;
	
	public MopokenGroup getMopoGroup() {
		return mopoGroup;
	}

	public void setMopoGroup(MopokenGroup mopoGroup) {
		this.mopoGroup = mopoGroup;
	}

    public Breeder() {
        this.mopoGroup = new MopokenGroup();
    }

    public String arrangeMopokens(MopokenGroup opponetMopokenGroup) {

    	MopokenGroupSorter sorter = new MopokenGroupSorter();
        return sorter.sort(this.mopoGroup, opponetMopokenGroup);
    }
}
