/**
 * 
 */
package com.mopo.demo.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * @author Guna Palani
 *
 */
public class MopokenGroup {
	
	private HashMap<MopokensType,Mopoken> mopokenSet = new LinkedHashMap<>();
	
    private List<Mopoken> sortedMopokens = new ArrayList<>();

    public HashMap<MopokensType, Mopoken> getMopokenSet() {
		return mopokenSet;
	}

	public void setMopokenSet(HashMap<MopokensType, Mopoken> mopokenSet) {
		this.mopokenSet = mopokenSet;
	}

	public List<Mopoken> getSortedMopokens() {
		return sortedMopokens;
	}

	public void setSortedMopokens(List<Mopoken> sortedMopokens) {
		this.sortedMopokens = sortedMopokens;
	}


    public boolean add(Mopoken mopoken) {
        if( size() >= 5 || mopokenSet.containsKey(mopoken.getType())){
            return  false;
        }
        mopokenSet.put(mopoken.getType(),mopoken);
        return true;
    }

    public int size() {
        return mopokenSet.size();
    }

    public Mopoken getMopoken(MopokensType type) {
        return mopokenSet.get(type);
    }

    public List<Mopoken> getAllMopokens(){
        return new ArrayList<Mopoken>(mopokenSet.values());
    }

    public String toString(){
        StringBuilder builder = new StringBuilder();
        final String[] prefix = {""};
        if (sortedMopokens.isEmpty()){
        	getAllMopokens().forEach( mopoken -> {
                builder.append(prefix[0]);
                prefix[0] =";";
                builder.append(mopoken.getType()).append("#").append(mopoken.getLevel());
            });
        }else{
        	sortedMopokens.forEach(mopoken->{
                builder.append(prefix[0]);
                prefix[0] =";";
                builder.append(mopoken.getType()).append("#").append(mopoken.getLevel());
            });
        }

        return builder.toString();
    }
}
