/**
 * 
 */
package com.mopo.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mopo.demo.exception.MopokensException;
import com.mopo.demo.model.Breeder;
import com.mopo.demo.service.MopokenService;

/**
 * @author Guna Palani
 *
 */
@RestController
public class MopokensController {
	
	@Autowired
	MopokenService mopoService;
	
	String finalResult = "";

	@RequestMapping("/")
	 public String welcome() {
		return "Welcome to Spring Boot Mopokens";
	 }
	 
	 @CrossOrigin(origins = "http://localhost:4200")
	 @RequestMapping(value="/mopokensFight", method = RequestMethod.POST)
	 public String mopokensFighter(ModelMap model, @RequestBody Map<String, Object> input) throws MopokensException {
		 
		 
        Breeder breeder = mopoService.createBreeder(input.get("breederInput").toString().trim());

        Breeder opponentBreeder = mopoService.createBreeder(input.get("oppBreederInput").toString().trim());
        
        finalResult = mopoService.startFight(breeder, opponentBreeder);
	        
		 return finalResult;
	 }
	 
	 
}
