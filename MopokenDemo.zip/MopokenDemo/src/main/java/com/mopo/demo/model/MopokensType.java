/**
 * 
 */
package com.mopo.demo.model;

/**
 * @author Guna Palani
 *
 */
public enum MopokensType {
    FIRE,
    WATER,
    GRASS,
    ELECTRIC,
    PSYCHIC,
    GHOST,
    FIGHTING
}
