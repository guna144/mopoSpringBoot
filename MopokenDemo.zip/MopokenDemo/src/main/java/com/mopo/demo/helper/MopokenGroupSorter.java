/**
 * 
 */
package com.mopo.demo.helper;

import java.util.ArrayList;
import java.util.List;

import com.mopo.demo.model.MopokenGroup;
import com.mopo.demo.model.Mopoken;

/**
 * @author Guna Palani
 *
 */
public class MopokenGroupSorter {
	
	public String sort(MopokenGroup myGroup, MopokenGroup opponentMopoGroup) {

        MopokenSelector selector = new MopokenSelector(myGroup);

        List<Mopoken> opponentMopokens = opponentMopoGroup.getAllMopokens();
        List<Mopoken> sortedMopoken = new ArrayList<Mopoken>();
        
        int sortScore = 0;
        int roundCount = 0;
        StringBuffer message = new StringBuffer();
        
        for (Mopoken mopoken : opponentMopokens) {
            MopokenResult mopokensByType = selector.findMopokensByType(mopoken);
            if(mopokensByType.getScore()> 0)
             sortScore += mopokensByType.getScore();

            List<Mopoken> matchedMopokens = mopokensByType.getResultList();
            Mopoken selectedMopokens = matchedMopokens.get(0);
            selectedMopokens.setAvailable(false);
            roundCount++;
            message.append(printResult(mopoken, mopokensByType, selectedMopokens,roundCount)+ "<br>");
            sortedMopoken.add(selectedMopokens);
        }
        
        myGroup.setSortedMopokens(sortedMopoken);
        message.append("Final result : <b>" + myGroup.toString() + "</b><br>");
        message.append("Score:" + sortScore + "/" + opponentMopokens.size());
        
        if (sortScore >= 3 || sortScore > opponentMopokens.size()/2) {
        	message.append(" - Possible Win");
        } else {
        	message.append(" - There are no chance of winning");
        }
        
        return message.toString();
    }

    private String printResult(Mopoken mopoken, MopokenResult mopokenByType, Mopoken selectedMopoken, int roundCount) {
    	String resultMsg = "";
        if (mopokenByType.getScore() > 0) {
        	resultMsg = "Round "+roundCount+ ": "+selectedMopoken.getType() + "#"+selectedMopoken.getLevel()+" has advantage than " +  mopoken.getType()  + "#" + mopoken.getLevel() + " (Type and level advantage)";
        } else if (mopokenByType.getScore() == 0) {
        	resultMsg = "Round "+roundCount+ ": "+selectedMopoken.getType() + "#"+selectedMopoken.getLevel()+ " and " +  mopoken.getType() + "#" + mopoken.getLevel() + " may result in a draw";
        } else {
        	resultMsg = "Round "+roundCount+ ": "+selectedMopoken.getType() + "#" + selectedMopoken.getLevel() + " does not have advantage over " + mopoken.getType() + "#" + mopoken.getLevel();
        }
        return resultMsg;
    }
}
