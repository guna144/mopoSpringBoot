/**
 * 
 */
package com.mopo.demo.model;

/**
 * @author Guna Palani
 *
 */
public class Mopoken implements Comparable {
	
	private MopokensType type;
    private Integer level;
    private boolean available = true;

    public Mopoken(){

    }

    public Mopoken(MopokensType type, Integer level) {
        this.setType(type);
        this.setLevel(level);
    }


    @Override
    public int compareTo(Object o2) {

        if( o2 instanceof Mopoken) {
        	Mopoken mopoken = (Mopoken) o2;
            if (this.equals(o2)) {
                return 0;
            } else if (this.getLevel() >= (2 * this.getLevel())) {
                return -1;
            } else if (this.getType() == MopokensType.FIRE && (mopoken.getType() == MopokensType.GRASS || mopoken.getType() == MopokensType.GHOST)) {
                return 1;
            } else if (this.getType() == MopokensType.WATER && mopoken.getType() == MopokensType.FIRE) {
                return 1;
            } else if (this.getType() == MopokensType.GRASS && (mopoken.getType() == MopokensType.ELECTRIC || mopoken.getType() == MopokensType.FIGHTING)) {
                return 1;
            } else if (this.getType() == MopokensType.ELECTRIC && mopoken.getType() == MopokensType.WATER) {
                return 1;
            } else if (this.getType() == MopokensType.PSYCHIC && mopoken.getType() == MopokensType.GHOST) {
                return 1;
            } else if (this.getType() == MopokensType.GHOST && (mopoken.getType() == MopokensType.FIGHTING
                    || mopoken.getType() == MopokensType.ELECTRIC)) {
                return 1;
            } else if (this.getType() == MopokensType.FIGHTING && mopoken.getType() == MopokensType.ELECTRIC) {
                return 1;
            }
        }

        return -1;
    }

	/**
	 * @return the type
	 */
	public MopokensType getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(MopokensType type) {
		this.type = type;
	}

	/**
	 * @return the level
	 */
	public Integer getLevel() {
		return level;
	}

	/**
	 * @param level the level to set
	 */
	public void setLevel(Integer level) {
		this.level = level;
	}

	/**
	 * @return the available
	 */
	public boolean isAvailable() {
		return available;
	}

	/**
	 * @param available the available to set
	 */
	public void setAvailable(boolean available) {
		this.available = available;
	}
}
