/**
 * 
 */
package com.mopo.demo.exception;

/**
 * @author Guna Palani
 *
 */
public class MopokensException extends Exception {
	public MopokensException(String message){
        super(message);
    }
}
