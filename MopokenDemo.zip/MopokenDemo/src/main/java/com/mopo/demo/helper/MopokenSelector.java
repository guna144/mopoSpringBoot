/**
 * 
 */
package com.mopo.demo.helper;

import java.util.Collections;
import java.util.Comparator;
import java.util.Optional;
import java.util.stream.Collectors;

import com.mopo.demo.comparator.MopokenCompartor;
import com.mopo.demo.model.MopokenGroup;
import com.mopo.demo.model.Mopoken;
import com.mopo.demo.model.MopokensType;

/**
 * @author Guna Palani
 *
 */
public class MopokenSelector {
	private MopokenGroup mopoGroup;

    public MopokenSelector(MopokenGroup myGroup) {
        this.mopoGroup = myGroup;
    }

    public MopokenResult findMopokensByType(Mopoken mopoken) {

        MopokenResult result = new MopokenResult(mopoken);

        if (mopoken.getType() == MopokensType.WATER) {
            result.add(mopoGroup.getMopoken(MopokensType.ELECTRIC));
            result.add(mopoGroup.getMopoken(MopokensType.WATER));

        } else if (mopoken.getType() == MopokensType.GRASS) {
            result.add(mopoGroup.getMopoken(MopokensType.FIRE));
            result.add(mopoGroup.getMopoken(MopokensType.GRASS));

        } else if (MopokensType.ELECTRIC == mopoken.getType()) {
            result.add(mopoGroup.getMopoken(MopokensType.GRASS));
            result.add(mopoGroup.getMopoken(MopokensType.GHOST));
            result.add(mopoGroup.getMopoken(MopokensType.FIGHTING));
            result.add(mopoGroup.getMopoken(MopokensType.ELECTRIC));

        } else if (MopokensType.GHOST == mopoken.getType()) {
            result.add(mopoGroup.getMopoken(MopokensType.FIRE));
            result.add(mopoGroup.getMopoken(MopokensType.PSYCHIC));
            result.add(mopoGroup.getMopoken(MopokensType.GHOST));

        } else if (mopoken.getType() == MopokensType.FIGHTING) {
            result.add(mopoGroup.getMopoken(MopokensType.GRASS));
            result.add(mopoGroup.getMopoken(MopokensType.GHOST));
            result.add(mopoGroup.getMopoken(MopokensType.FIGHTING));
        } else if (mopoken.getType() == MopokensType.FIRE) {
            result.add(mopoGroup.getMopoken(MopokensType.WATER));
            result.add(mopoGroup.getMopoken(MopokensType.GHOST));
            result.add(mopoGroup.getMopoken(MopokensType.FIRE));

        } else if (mopoken.getType() == MopokensType.PSYCHIC) {
            result.add(mopoGroup.getMopoken(MopokensType.PSYCHIC));
        }

        result.getResultList().removeAll(Collections.singleton(null));

        if (result.getResultList().isEmpty()) {
            Optional<Mopoken> any = mopoGroup.getAllMopokens().stream().filter(mopoken1 -> (mopoken.getLevel().equals(mopoken1.getLevel()) && mopoken1.isAvailable())).findFirst();
            if (any.isPresent()) {
                result.getResultList().add(any.get());
            }
        }

        if (result.getResultList().isEmpty()) {
            Optional<Mopoken> max = mopoGroup.getAllMopokens().stream().filter(mopoken1 -> mopoken1.isAvailable()).max(Comparator.comparing(Mopoken::getLevel));
            if (max.isPresent()) {
                result.getResultList().add(max.get());
                result.setScore(new MopokenCompartor().compare(max.get(), mopoken));
            }
        }

        result.getResultList().stream().sorted(Comparator.comparing(mopoken1 -> mopoken.getLevel())).collect(Collectors.toList());
        return result;
    }
}
