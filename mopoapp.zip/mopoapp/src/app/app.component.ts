import { Component } from '@angular/core';
import { DataService } from './_services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  submitted = false; 
  data: string; 
  message : any;

  constructor(private _service : DataService){}

  onSubmit(data) {
      this.submitted = true;
      this.data = JSON.stringify(data);
      this._service.fightService(this.data).subscribe(res =>  this.message = res._body);
  }
}
