import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

@Injectable()
export class DataService {
 
  url : string = "http://localhost:8090/mopokensFight";

  headers = new Headers({ 'Content-Type': 'application/json' });
  options = new RequestOptions({ headers: this.headers });

  constructor(private _http : Http) { }

  fightService(param : any) : Observable<any> {
    return this._http.post(this.url,param,this.options).map((res : Response) => res);
  }
}
